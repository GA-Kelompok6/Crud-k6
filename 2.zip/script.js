const signUpBtn = document.getElementById('signUp');
const loginBtn = document.getElementById('login');
const container = document.getElementById('container');

signUpBtn.addEventListener('click', () => {
   container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
   container.classList.remove("active");
});